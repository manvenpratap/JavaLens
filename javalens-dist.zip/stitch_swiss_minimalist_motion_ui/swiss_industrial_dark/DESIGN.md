---
name: Swiss-Industrial Dark
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#3a3939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#bbcabf'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#86948a'
  outline-variant: '#3c4a42'
  surface-tint: '#4edea3'
  primary: '#4edea3'
  on-primary: '#003824'
  primary-container: '#10b981'
  on-primary-container: '#00422b'
  inverse-primary: '#006c49'
  secondary: '#adc6ff'
  on-secondary: '#002e6a'
  secondary-container: '#0566d9'
  on-secondary-container: '#e6ecff'
  tertiary: '#ffb95f'
  on-tertiary: '#472a00'
  tertiary-container: '#e29100'
  on-tertiary-container: '#523200'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#6ffbbe'
  primary-fixed-dim: '#4edea3'
  on-primary-fixed: '#002113'
  on-primary-fixed-variant: '#005236'
  secondary-fixed: '#d8e2ff'
  secondary-fixed-dim: '#adc6ff'
  on-secondary-fixed: '#001a42'
  on-secondary-fixed-variant: '#004395'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
  surface-deep: '#000000'
  surface-muted: '#171717'
  border-subtle: '#262626'
  text-high-contrast: '#FFFFFF'
  text-low-contrast: '#A3A3A3'
  code-added: '#064E3B'
  code-removed: '#7F1D1D'
  code-modified: '#1E3A8A'
typography:
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.04em
  headline-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  code-md:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '450'
    lineHeight: '1.7'
  label-caps:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '700'
    lineHeight: '1'
    letterSpacing: 0.1em
  table-data:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: '1.4'
spacing:
  grid-margin: 2rem
  grid-gutter: 1rem
  stack-xs: 0.25rem
  stack-sm: 0.5rem
  stack-md: 1.5rem
  stack-lg: 3rem
  section-gap: 6rem
---

## Brand & Style

This design system is built on the principles of **Swiss Design (International Typographic Style)**, adapted for a high-performance developer tool environment. The aesthetic is anchored by a rigid mathematical grid, asymmetrical layouts that favor information density, and a stark, "Dark Mode" first approach.

The visual narrative prioritizes technical precision and objective clarity. It evokes a sense of "premium utility"—where every pixel serves a functional purpose. The interface utilizes high-contrast accents against deep, monolithic backgrounds to draw focus to code-related delta reports and AST analysis results.

**Key Stylistic Pillars:**
- **Asymmetry:** Layouts avoid centered content, opting for left-aligned hierarchies and varied column widths to create a dynamic yet structured flow.
- **Micro-interactions:** Transitions are immediate and linear, mirroring the speed of the underlying Java Compiler Tree API.
- **Negative Space:** Generous structural whitespace is used not just for aesthetics, but as a functional separator for complex datasets.

## Colors

The palette is designed for prolonged focus during deep codebase analysis. The foundation is a "True Black" (`#000000`) and "Near Black" (`#0A0A0A`) core to minimize eye strain and maximize the perceived contrast of data.

- **Primary (Emerald):** Used exclusively for successful operations, "Added" states in diffs, and primary action triggers.
- **Secondary (Vibrant Blue):** Dedicated to "Modified" states and interactive AST nodes.
- **Tertiary (Amber):** Reserved for warnings and execution status markers in the CLI-style dashboard.
- **Neutrals:** A strict scale of grays that defines the structural hierarchy without adding visual noise.

**Color Application:**
Use the `code-` named colors for background highlights in diff comparison views, ensuring text remains `text-high-contrast` for legibility. Transitions between color states should be `150ms` linear.

## Typography

Typography is the primary driver of this design system's character. We pair the precision of **Hanken Grotesk** for high-level structure with the utilitarian clarity of **Inter** for UI controls. **JetBrains Mono** is utilized for all data-heavy outputs, CSV previews, and method signatures to maintain the developer-centric feel.

**Rules for Use:**
- **Headlines:** Must always be left-aligned. Tight letter-spacing is required for the `headline-lg` level to achieve the Swiss editorial look.
- **Monospace:** Use `code-md` for any text representing Java class attributes, method signatures, or file paths.
- **Labels:** Use `label-caps` for table headers and category markers to provide clear visual separation from content.

## Layout & Spacing

The system employs a **12-column fixed-fluid hybrid grid**. While the outer container obeys a max-width for readability, the internal columns provide a rigid framework for asymmetrical placement.

- **The Baseline:** All vertical spacing must be a multiple of `4px` (0.25rem) to ensure a consistent rhythmic "beat" across the interface.
- **Asymmetry:** In the "Compare Mode" dashboard, use a 4-column sidebar for navigation/filters and an 8-column main area for the diff reports.
- **Structural Whitespace:** Large gaps (`section-gap`) are used between distinct logical blocks (e.g., between the "Configuration Editor" and the "Execution Status").
- **Responsive Reflow:** On mobile, the 12-column grid collapses to 4 columns. Gaps are reduced by 50% to maintain density without sacrificing touch targets.

## Elevation & Depth

To maintain the Swiss/Minimalist aesthetic, traditional shadows are strictly prohibited. Depth is communicated through **Tonal Layers** and **Subtle Outlines**.

- **Surface Tiers:** 
    - Base: `#000000` (The void)
    - Container: `#0A0A0A` (Raised surfaces)
    - Overlay/Popovers: `#171717` (Floating menus)
- **Borders:** Surfaces are separated by 1px solid lines using `border-subtle` (`#262626`). These borders should be the primary method of defining structural boundaries.
- **Active State Elevation:** When an element is focused or active (e.g., a selected method in a list), use a 1px border of `primary_color_hex` rather than a shadow. This creates a "technical highlight" effect.

## Shapes

The design system uses a **Sharp (0px)** roundedness philosophy. This reinforces the "Industrial/Technical" nature of a static analyzer. 

All UI elements—including buttons, input fields, and cards—must have square corners. This allows elements to sit perfectly flush against the grid lines and each other, creating a modular, "built-in" appearance. The only exception is for circular status indicators (e.g., a small pulsing dot for "Execution Status").

## Components

### Buttons
Buttons are strictly rectangular with 1px borders. 
- **Primary:** Background of `primary_color_hex`, text `neutral_color_hex` (Black).
- **Ghost:** Transparent background, 1px border of `border-subtle`. On hover, border becomes `text-high-contrast`.

### Input Fields
Inputs use `surface-muted` as a background with a 1px `border-subtle` bottom border only. This mimics a terminal input line. Focused states transition the bottom border to `secondary_color_hex`.

### Data Tables (CSV Previews)
Tables are the heart of the tool. Use `table-data` typography. Rows are separated by 1px `border-subtle`. Alternate row striping is not used; instead, use a highlight on hover to assist with horizontal eye tracking.

### Status Chips
Used for `ADDED`, `REMOVED`, or `MODIFIED` tags. These are rectangular blocks with no padding on the sides, using `label-caps` typography and a high-contrast background of the respective state color.

### Code Blocks
Code containers use `surface-deep` and `code-md` font. Syntax highlighting should follow a "monochrome-plus-accent" style: mostly white/gray text with primary and secondary colors used sparingly for keywords and operators.